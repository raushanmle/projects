# Pluralsight

## Tensorflow: Getting Started

Code samples from the course [Tensorflow: Getting Started](https://app.pluralsight.com/library/courses/tensorflow-getting-started/table-of-contents) from [Pluralsight](https://www.pluralsight.com/).